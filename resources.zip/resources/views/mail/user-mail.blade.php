User Name : {{ $data->name }}<br>
User Contact : {{ $data->contact }}<br>
User Email : {{ $data->email }}<br><hr>
User Details : {{ $data->details }}
