<h1>Applicant data for new franchisee </h1><hr>
Applicant Name : {{ $data->name }}<br>
Applicant Age : {{ $data->age }}<br>
Applicant Occupation : {{ $data->occupation }}<br>
Applicant Gender : {{ $data->gender }}
Applicant Email : {{ $data->email }}<br>
Applicant Contact : {{ $data->contact }}<br>
Applicant Location : {{ $data->location }}<br>
Applicant Address : {{ $data->address }}<br><hr>

